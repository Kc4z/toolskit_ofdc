def f1():
    print('f1')
    
def f1():
    print('f3')
    
def f1():
    print('f2')